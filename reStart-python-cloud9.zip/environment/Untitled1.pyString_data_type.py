#Exercise 1
myString ="This is a string."
print(myString)
print(type(myString))
print(myString + " is of the data type " + str(type(myString)))
# Exercise 2
firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)
# Exercise 3
name = input("what is your name ? ")
print(name)
#Exercise 4
color = input("what is your favorite color?")
animal = input("what is your favorite animal?")
print("{} you like a {} {}!".format(name,color,animal))

