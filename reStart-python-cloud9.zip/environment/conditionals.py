userReply = input("Do you need to ship the package? (Enter yes or no)")

if userReply == "yes":
    print("We can help you ship that package!")
elif userReply == "no":
    print("Please come back when you need to ship a package. Thank you.")
else:
    print("Silahkan input yang benar")
    
    